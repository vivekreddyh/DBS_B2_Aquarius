import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-updatebank',
  templateUrl: './updatebank.component.html',
  styleUrls: ['./updatebank.component.css']
})
export class UpdatebankComponent implements OnInit {
  updateDataStatus:boolean=false;
  registration:any;
  data:any;
  x:string="123";
  buttonStatus:boolean=false;
  constructor(public router:Router,public http:HttpClient) { }

  ngOnInit() {
  }
  onSubmit(form:any){
    var acc_no:String = form.value.accountnumber;
    debugger
    this.buttonStatus=true;
        this.http.get("http://localhost:9004/webs/registrations/"+acc_no)
        .toPromise()
        .then(
          (data)=>{console.log("in data block");
          debugger;
          this.data=data;
    var todate=new Date(this.data.date_of_birth).getDate();
    var tomonth=new Date(this.data.date_of_birth).getMonth()+1;
    var toyear=new Date(this.data.date_of_birth).getFullYear();
    var original_date=tomonth+'/'+todate+'/'+toyear;
    this.data.date_of_birth=original_date;
    debugger;},
          (error)=>{console.log("in error block");console.log(error);}
        )
        .catch((err) => {
          console.log("In catch block");
          console.log(err);
        })
        .finally(()=>{console.log("in finally");});
        console.log(this.data);
  }
  onClick(){
  console.log("in onclick()")
    this.http.put("http://localhost:9004/webs/registrations",{
      "pan_no":this.data.panno,
      "firstname": this.data.fname,
      "middlename": this.data.mname,
      "lastname": this.data.lname,
      "phone_no": this.data.phno,
      "email_id":this.data.email,
      "date_of_birth": this.data.dob,
      "address": this.data.address,
      "zipcode": this.data.zipcode,
      "account_type": this.data.acctype,
      "balance": this.data.balance,
      "ifsc_code": this.data.ifsc,
      "account_status":this.data.accstatus
    })
    .toPromise()
    .then(
      (data)=>{console.log("in data block");},
      (error)=>{console.log("in error block");console.log(error);}
    )
    .catch((err) => {
      console.log("In catch block");
      console.log(err);
    })
    .finally(()=>{console.log("in finally");});
  }

}
