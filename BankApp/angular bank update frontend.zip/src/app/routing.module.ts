import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes } from '@angular/router';
import { CustregistrationComponent } from './custregistration/custregistration.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { BankregisComponent } from './bankregis/bankregis.component';
import { PasswordsetComponent } from './passwordset/passwordset.component';
import { AppComponent } from './app.component';
import { ErrorcomponentComponent } from './errorcomponent/errorcomponent.component';
import { UpdatebankComponent } from './updatebank/updatebank.component';
import { UpdatefieldsComponent } from './updatefields/updatefields.component';

export const router:Routes=[
  {path:"",redirectTo:"app",pathMatch:"full"},
  {path:"app",component:AppComponent},
  {path:"passwdreset/:custid",component:PasswordsetComponent},
  {path:"registration",component:CustregistrationComponent},
  {path:"bankregis",component:BankregisComponent},
  {path:"bankupdate",component:UpdatebankComponent},
  {path:"bankdataupdate/:accid",component:UpdatefieldsComponent},
  {path:"error",component:ErrorcomponentComponent},
  {path:"**",component:ErrorcomponentComponent},
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(router)
  ],
  exports:[RouterModule]
})
export class RoutingModule { }
