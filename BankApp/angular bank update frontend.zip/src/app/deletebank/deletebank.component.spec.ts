import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletebankComponent } from './deletebank.component';

describe('DeletebankComponent', () => {
  let component: DeletebankComponent;
  let fixture: ComponentFixture<DeletebankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeletebankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletebankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
