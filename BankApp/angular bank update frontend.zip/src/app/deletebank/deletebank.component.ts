import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-deletebank',
  templateUrl: './deletebank.component.html',
  styleUrls: ['./deletebank.component.css']
})
export class DeletebankComponent implements OnInit {
   data:any;
   buttonstatus:boolean=false;
  constructor(public http:HttpClient) { }

  ngOnInit() {
  }
  onSubmit(){
    this.buttonstatus=true;
         this.http.get("http://localhost:9004/acct/CustAcct/"+"138910011111")
            .toPromise()
            .then(
              (data)=>{console.log("in data block");debugger;console.log(data); this.data=data;},
              (error)=>{console.log("in error block");console.log(error);}
            )
            .catch((err) => {
              console.log("In catch block");
              console.log(err);
            })
            .finally(()=>{console.log("in finally");});
  }
}
