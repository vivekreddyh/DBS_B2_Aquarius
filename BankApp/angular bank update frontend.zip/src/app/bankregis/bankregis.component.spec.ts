import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankregisComponent } from './bankregis.component';

describe('BankregisComponent', () => {
  let component: BankregisComponent;
  let fixture: ComponentFixture<BankregisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankregisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankregisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
