import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-updatefields',
  templateUrl: './updatefields.component.html',
  styleUrls: ['./updatefields.component.css']
})
export class UpdatefieldsComponent implements OnInit {
  sub:any;
  dataStatus:boolean=false;
  registrations:Object=[];
  constructor(public route:ActivatedRoute) { }

  ngOnInit() {
    debugger
    this.sub = this.route.params
    .subscribe( p => {
      debugger
      this.registrations = <any>p['accid'];
      this.dataStatus=true;
      });
      console.log(this.registrations);
    }
}
