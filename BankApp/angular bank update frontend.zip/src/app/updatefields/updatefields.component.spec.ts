import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatefieldsComponent } from './updatefields.component';

describe('UpdatefieldsComponent', () => {
  let component: UpdatefieldsComponent;
  let fixture: ComponentFixture<UpdatefieldsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatefieldsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatefieldsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
