import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-custregistration',
  templateUrl: './custregistration.component.html',
  styleUrls: ['./custregistration.component.css']
})
export class CustregistrationComponent implements OnInit {
  termsStatus:boolean=false;
  accStatus: boolean = false;
  panStatus: boolean = false;
  registerStatus:boolean=true;
  accnumber:number;
  pannumber:string="";
  data:any=[];
  constructor(public http:HttpClient,public router:Router) { 
  }
  ngOnInit() {
  }
  onSubmit(form:NgForm){
    if(form.valid == true){
      console.log("hi");
       debugger
       this.data= this.http.post("http://localhost:9004/regis/custregis",
        {
            "acc_no": form.value.accountnumber,
            "pan_no": form.value.pan
        })
        .toPromise()
        .then(
            data => {
                console.log("POST Request is successful ", data);
                if(data["response"] == "Success"){
                    this.router.navigate(['/passwdreset/'+data["custid"]]);
                }
                else{
                  this.router.navigate(['/error']);
                }
            },
            error => {
                console.log("Error", error);
            }
        ); 
        console.log(this.data);
    }
  }
}
