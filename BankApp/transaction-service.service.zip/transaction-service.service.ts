import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransactionServiceService {

  statusForTransaction : string ='';
  constructor() { }
  
}
