import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-custregistration',
  templateUrl: './custregistration.component.html',
  styleUrls: ['./custregistration.component.css']
})
export class CustregistrationComponent implements OnInit {
  termsStatus:boolean=false;
  accStatus: boolean = false;
  panStatus: boolean = false;
  registerStatus:boolean=true;
  accnumber:number;
  pannumber:string="";
  constructor(public http:HttpClient) { 
  }
  ngOnInit() {
  }
  onSubmit(form:NgForm){
    if(form.valid == true){
      console.log("hi");
        // this.http.get("http://localhost:9004/regis/hi")
        // .toPromise()
        // .then(
        //   (data)=>{console.log("in data block");console.log(data); },
        //   (error)=>{console.log("in error block");console.log(error);}
        // )
        // .catch((err) => {
        //   console.log("In catch block");
        //   console.log(err);
        // })
        // .finally(()=>{console.log("in finally");});
      
       debugger
        this.http.post("http://localhost:9004/regis/custregis",
        {
            "acc_no": form.value.accountnumber,
            "pan_no": form.value.pan
        })
        .toPromise()
        .then(
            data => {
                console.log("POST Request is successful ", data);
            },
            error => {
                console.log("Error", error);
            }
        ); 
    }
  }
}
