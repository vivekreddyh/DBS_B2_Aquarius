import { CheckpasswordPipe } from './checkpassword.pipe';

describe('CheckpasswordPipe', () => {
  it('create an instance', () => {
    const pipe = new CheckpasswordPipe();
    expect(pipe).toBeTruthy();
  });
});
