import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { CustregistrationComponent } from './custregistration/custregistration.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { BankregisComponent } from './bankregis/bankregis.component';
import { PasswordsetComponent } from './passwordset/passwordset.component';
import { CheckpasswordPipe } from './checkpassword.pipe';

@NgModule({
  declarations: [
    AppComponent,
    CustregistrationComponent,
    UserregistrationComponent,
    BankregisComponent,
    PasswordsetComponent,
    CheckpasswordPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
