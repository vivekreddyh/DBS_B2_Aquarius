import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-uicomp',
  templateUrl: './new-uicomp.component.html',
  styleUrls: ['./new-uicomp.component.css']
})
export class NewUICompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
