import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-bankregis',
  templateUrl: './bankregis.component.html',
  styleUrls: ['./bankregis.component.css']
})
export class BankregisComponent implements OnInit {
  buttstatus:boolean=false;
  constructor() { }

  ngOnInit() {
  }
 onClick(){
   this.buttstatus=true;
 }
 onSubmit(form: NgForm){
   debugger
   console.log("hi");
   console.log(form);
 }
}
