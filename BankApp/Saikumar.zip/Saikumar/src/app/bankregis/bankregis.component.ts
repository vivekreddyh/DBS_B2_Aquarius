import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bankregis',
  templateUrl: './bankregis.component.html',
  styleUrls: ['./bankregis.component.css']
})
export class BankregisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
