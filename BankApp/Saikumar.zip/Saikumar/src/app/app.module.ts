import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { CustregistrationComponent } from './custregistration/custregistration.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { BankregisComponent } from './bankregis/bankregis.component';

@NgModule({
  declarations: [
    AppComponent,
    CustregistrationComponent,
    UserregistrationComponent,
    BankregisComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
