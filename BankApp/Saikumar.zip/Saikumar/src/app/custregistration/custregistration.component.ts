import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custregistration',
  templateUrl: './custregistration.component.html',
  styleUrls: ['./custregistration.component.css']
})
export class CustregistrationComponent implements OnInit {
  termsStatus:boolean=false;
  accStatus: boolean = false;
  panStatus: boolean = false;
  registerStatus=true;
  accnumber:number;
  pannumber:string="";
  constructor() { 
  }
  ngOnInit() {
  }
  onClick(){
    this.termsStatus = true;
    if(this.pannumber!=""){
      this.panStatus=true;
    }
    else
     this.panStatus=false;
    this.registerStatus= (this.accStatus&&this.panStatus&&this.termsStatus)?false:true;
  }
  panno(){
     
  }
}
