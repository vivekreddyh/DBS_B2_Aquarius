import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-custregistration',
  templateUrl: './custregistration.component.html',
  styleUrls: ['./custregistration.component.css']
})
export class CustregistrationComponent implements OnInit {
  termsStatus:boolean=false;
  accStatus: boolean = false;
  panStatus: boolean = false;
  registerStatus:boolean=true;
  accnumber:number;
  pannumber:string="";
  constructor() { 
  }
  ngOnInit() {
  }
  onSubmit(form:NgForm){
   // debugger
    console.log(form);
    if(form.valid == true){
        this.registerStatus=false;
    }
  }
}
