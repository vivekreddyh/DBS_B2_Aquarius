package com.example.demo.userlogin;
import java.sql.Timestamp;
import java.util.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/rest")
public class RestUserLoginController {
	


	@Autowired
	UserLoginDBDao usr;

	@GetMapping("/user/{userid}/{password}") 
	public Map<String, String> isValidCredentials(@PathVariable int userid,@PathVariable String password)
	{
		HashMap<String,String> hm=new HashMap<>();
//		PasswordEncoder encoder = new BCryptPasswordEncoder();
//		String pwd = encoder.encode(password);
		System.out.println("in map get");
	if(usr.getCredentials(userid,password).size() == 1) {
		Optional<User_Login> u=usr.findById(userid);
		User_Login user = u.get();			
		Date date= new Date();
		 long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		hm.put("response", "success");
		hm.put("timestamp", ts+"");
		System.out.println(hm);
		return hm;
	}	
	  return Collections.singletonMap("response","failure");
	}

	
}
