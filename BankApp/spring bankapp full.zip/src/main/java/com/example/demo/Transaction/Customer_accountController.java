package com.example.demo.Transaction;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customerAccount")
@CrossOrigin("*")
public class Customer_accountController {
	@Autowired
	CustAccountDAO custAccountDAO;
	
	@GetMapping("/getCustomerAccountDetails/{id}")
	public Optional<Customer_account> getTransactionsById(@PathVariable String id){
		System.out.println("The Account  number is "+id);
		System.out.println( custAccountDAO.findById(id));
		return  custAccountDAO.findById(id);
	}
}
