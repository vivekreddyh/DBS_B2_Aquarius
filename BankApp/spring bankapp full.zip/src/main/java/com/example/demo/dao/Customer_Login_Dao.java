/**
 * 
 */
package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Customer_Login;

/**
 * @author Abridge Solutions
 *
 */
public interface Customer_Login_Dao extends JpaRepository<Customer_Login,Integer>{
	
}
