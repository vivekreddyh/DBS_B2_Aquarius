package com.example.demo;

public class Customer_Registration {
	String acc_no;
	String pan_no;
	public Customer_Registration() {
		// TODO Auto-generated constructor stub
	}
	public Customer_Registration(String acc_no, String pan_no) {
		super();
		this.acc_no = acc_no;
		this.pan_no = pan_no;
	}
	@Override
	public String toString() {
		return "Customer_Registration [acc_no=" + acc_no + ", pan_no=" + pan_no + "]";
	}
	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public String getPan_no() {
		return pan_no;
	}
	public void setPan_no(String pan_no) {
		this.pan_no = pan_no;
	}
	
}
