import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from 'selenium-webdriver/http';

@Component({
  selector: 'app-errorcomponent',
  templateUrl: './errorcomponent.component.html',
  styleUrls: ['./errorcomponent.component.css']
})
export class ErrorcomponentComponent implements OnInit {
  
  constructor(public router:Router) { }

  ngOnInit() {
  }
  onSubmit(){
     this.router.navigate(['/bankregis']);
  }

}
