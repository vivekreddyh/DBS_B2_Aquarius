package com.example.demo.Transaction;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustAccountDAO extends JpaRepository<Customer_account, String>{

}
